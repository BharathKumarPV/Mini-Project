# KisanConnect

**India's Agriculture Market, Connected.**

A production-style full-stack web application for tracking Indian mandi prices, comparing agricultural markets, and connecting farmers directly with buyers.

---

## Features

- **Live Mandi Prices** — Real data from [data.gov.in](https://data.gov.in) AGMARKNET (Government of India open data portal)
- **Price History & Trends** — 90-day historical charts using Recharts
- **Market Comparison** — Side-by-side price comparison across APMC markets (indicative only)
- **Market Map** — Interactive Leaflet/OpenStreetMap map of APMC markets
- **Marketplace** — Farmers list produce; buyers discover and order with full price transparency
- **Dashboards** — Role-based dashboards for Farmers, Buyers, and Admins
- **Price Alerts** — Set alerts when commodity prices go above or below a target
- **Data Freshness Badges** — Every price table shows source, data date, and last sync time

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, TypeScript, Tailwind CSS |
| Charts | Recharts |
| Maps | Leaflet + OpenStreetMap (free, no API key) |
| Backend | Node.js, Express, TypeScript |
| Database | SQLite + Prisma ORM |
| Auth | JWT (localStorage) |
| Data | data.gov.in AGMARKNET API |

---

## Quick Start

### Prerequisites
- Node.js 18+
- npm 9+

### 1. Clone and install

```bash
git clone https://github.com/BharathKumarPV/Mini-Project.git
cd Mini-Project
npm run install:all
```

### 2. Configure backend environment

```bash
cp backend/.env.example backend/.env
```

Edit `backend/.env`:
- `DATA_GOV_API_KEY`: Get a free key at https://data.gov.in/user/register — **optional** for dev, required for live data
- `JWT_SECRET`: Change to a secure random string for production

### 3. Set up database and seed demo data

```bash
npm run db:setup
```

This runs:
1. `prisma generate` — generates Prisma client
2. `prisma db push` — creates SQLite database
3. `tsx src/seed.ts` — seeds demo data

### 4. Start the application

```bash
npm run dev
```

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3000

---

## Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@kisanconnect.in | admin123 |
| Farmer | farmer@demo.in | farmer123 |
| Buyer | buyer@demo.in | buyer123 |

---

## Live Mandi Data Setup

To enable live AGMARKNET data from the Government of India:

1. Register at https://data.gov.in/user/register (free)
2. Get your API key
3. Add to `backend/.env`:
   ```
   DATA_GOV_API_KEY=your-key-here
   ```
4. Restart the backend — sync starts automatically
5. Or trigger manually: Admin Dashboard → "Trigger Sync Now"

**Data Resource**: [Current Daily Price of Various Commodities](https://data.gov.in/resource/current-daily-price-various-commodities-various-markets-mandi)

---

## API Endpoints

### Public

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard/stats` | Platform statistics |
| GET | `/api/markets` | List markets (paginated) |
| GET | `/api/markets/states` | Distinct states with market counts |
| GET | `/api/markets/:id` | Market detail |
| GET | `/api/markets/:id/prices` | Prices for a market |
| GET | `/api/commodities` | List commodities |
| GET | `/api/commodities/:id` | Commodity detail |
| GET | `/api/commodities/:id/prices` | Prices for a commodity |
| GET | `/api/prices/latest` | Latest prices with filters |
| GET | `/api/prices/history` | Price history (date range) |
| GET | `/api/prices/compare` | Compare prices across markets |
| GET | `/api/marketplace/products` | Marketplace listings |
| GET | `/api/marketplace/products/:id` | Product detail with price transparency |

### Authenticated

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Current user |
| POST | `/api/marketplace/products` | Create listing (FARMER) |
| POST | `/api/orders` | Place order (BUYER) |
| PATCH | `/api/orders/:id/status` | Update order status |
| GET | `/api/dashboard/farmer` | Farmer dashboard data |
| GET | `/api/dashboard/buyer` | Buyer dashboard data |
| GET/POST | `/api/alerts` | Price alerts |

### Admin Only

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/stats` | Platform stats |
| GET | `/api/admin/users` | User management |
| POST | `/api/admin/sync` | Trigger data sync |
| GET | `/api/admin/sync/status` | Sync status |
| GET | `/api/admin/sync/logs` | Sync logs |

---

## Project Structure

```
kisanconnect/
├── package.json              # Root scripts (dev, setup, etc.)
├── README.md
├── database/
│   └── kisanconnect.db       # SQLite database (auto-created)
├── backend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env.example
│   ├── prisma/
│   │   └── schema.prisma     # Database schema
│   └── src/
│       ├── index.ts          # Express app entry point
│       ├── lib/
│       │   └── prisma.ts     # Prisma singleton
│       ├── middleware/
│       │   ├── auth.ts       # JWT middleware
│       │   └── roles.ts      # Role guard
│       ├── routes/           # Express routers
│       ├── services/         # Business logic
│       └── seed.ts           # Demo data seeder
└── frontend/
    ├── package.json
    ├── vite.config.ts
    ├── tailwind.config.js
    ├── index.html
    └── src/
        ├── App.tsx           # Router
        ├── api/              # Axios API clients
        ├── hooks/            # React hooks (auth, prices, marketplace)
        ├── components/       # Reusable components
        ├── pages/            # Route-level pages
        └── types/            # TypeScript types
```

---

## Data Disclaimers

- Mandi price data is sourced from [data.gov.in](https://data.gov.in) (AGMARKNET/NHM).
- Prices are indicative wholesale rates as reported by APMC markets.
- Prices shown without API key are demo/cached data generated by the seed script.
- All marketplace listings marked **[DEMO]** are for demonstration only.
- Market comparisons show **indicative price differences** only — they do not account for transport costs, mandi fees, quality variation, or local factors.

---

## License

MIT License. Data sourced from Government of India open data portals under NDP/OGD license.
