import { Router, Response } from 'express';
import { prisma } from '../lib/prisma';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/dashboard/stats - public stats for landing page
router.get('/stats', async (_req, res: Response): Promise<void> => {
  const [markets, commodities, products, states] = await Promise.all([
    prisma.market.count({ where: { isActive: true } }),
    prisma.commodity.count(),
    prisma.product.count({ where: { isActive: true } }),
    prisma.market.groupBy({ by: ['state'], _count: { id: true } }),
  ]);

  res.json({
    markets,
    commodities,
    products,
    states: states.length,
  });
});

// GET /api/dashboard/farmer - farmer dashboard data
router.get('/farmer', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  if (req.user!.role !== 'FARMER' && req.user!.role !== 'ADMIN') {
    res.status(403).json({ error: 'Farmer access required' });
    return;
  }

  const [products, orders, notifications, profile] = await Promise.all([
    prisma.product.findMany({
      where: { farmerId: req.user!.id },
      include: { commodity: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.order.findMany({
      where: { farmerId: req.user!.id },
      include: {
        buyer: { select: { id: true, name: true } },
        items: { include: { product: { select: { title: true } } } },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.notification.findMany({
      where: { userId: req.user!.id, isRead: false },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.farmerProfile.findUnique({ where: { userId: req.user!.id } }),
  ]);

  const [totalRevenue, activeProducts, pendingOrders] = await Promise.all([
    prisma.order.aggregate({
      where: { farmerId: req.user!.id, status: { in: ['COMPLETED', 'READY'] } },
      _sum: { totalAmount: true },
    }),
    prisma.product.count({ where: { farmerId: req.user!.id, isActive: true } }),
    prisma.order.count({ where: { farmerId: req.user!.id, status: 'PENDING' } }),
  ]);

  res.json({
    profile,
    recentProducts: products,
    recentOrders: orders,
    notifications,
    stats: {
      totalRevenue: totalRevenue._sum.totalAmount ?? 0,
      activeProducts,
      pendingOrders,
      totalOrders: await prisma.order.count({ where: { farmerId: req.user!.id } }),
    },
  });
});

// GET /api/dashboard/buyer - buyer dashboard data
router.get('/buyer', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  if (req.user!.role !== 'BUYER' && req.user!.role !== 'ADMIN') {
    res.status(403).json({ error: 'Buyer access required' });
    return;
  }

  const [orders, notifications, favorites, profile] = await Promise.all([
    prisma.order.findMany({
      where: { buyerId: req.user!.id },
      include: {
        farmer: { select: { id: true, name: true } },
        items: { include: { product: { select: { title: true, commodity: { select: { name: true } } } } } },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.notification.findMany({
      where: { userId: req.user!.id, isRead: false },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    prisma.favorite.findMany({
      where: { userId: req.user!.id },
      include: {
        product: {
          include: { commodity: { select: { name: true } }, farmer: { select: { name: true } } },
        },
      },
      take: 5,
    }),
    prisma.buyerProfile.findUnique({ where: { userId: req.user!.id } }),
  ]);

  const totalSpent = await prisma.order.aggregate({
    where: { buyerId: req.user!.id, status: { in: ['COMPLETED', 'READY'] } },
    _sum: { totalAmount: true },
  });

  res.json({
    profile,
    recentOrders: orders,
    notifications,
    favorites,
    stats: {
      totalOrders: await prisma.order.count({ where: { buyerId: req.user!.id } }),
      totalSpent: totalSpent._sum.totalAmount ?? 0,
      pendingOrders: await prisma.order.count({ where: { buyerId: req.user!.id, status: 'PENDING' } }),
      savedProducts: await prisma.favorite.count({ where: { userId: req.user!.id } }),
    },
  });
});

export default router;
