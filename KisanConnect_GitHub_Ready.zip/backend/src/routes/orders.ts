import { Router, Response } from 'express';
import { prisma } from '../lib/prisma';
import { authenticate, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/orders - list orders for current user
router.get('/', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  const { role } = req.user!;
  const { status, page = '1', limit = '20' } = req.query;

  const pageNum = Math.max(1, parseInt(String(page)));
  const limitNum = Math.min(50, Math.max(1, parseInt(String(limit))));
  const skip = (pageNum - 1) * limitNum;

  const where: Record<string, unknown> = {};
  if (role === 'FARMER') where.farmerId = req.user!.id;
  else if (role === 'BUYER') where.buyerId = req.user!.id;
  if (status) where.status = String(status).toUpperCase();

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      skip,
      take: limitNum,
      orderBy: { createdAt: 'desc' },
      include: {
        buyer: { select: { id: true, name: true, email: true } },
        farmer: { select: { id: true, name: true, email: true } },
        items: {
          include: { product: { select: { id: true, title: true, commodity: { select: { name: true } } } } },
        },
      },
    }),
    prisma.order.count({ where }),
  ]);

  res.json({
    data: orders,
    pagination: { page: pageNum, limit: limitNum, total, pages: Math.ceil(total / limitNum) },
  });
});

// GET /api/orders/:id
router.get('/:id', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  const order = await prisma.order.findUnique({
    where: { id: req.params.id },
    include: {
      buyer: { select: { id: true, name: true, email: true, mobile: true } },
      farmer: { select: { id: true, name: true, email: true, mobile: true } },
      items: {
        include: {
          product: {
            select: {
              id: true,
              title: true,
              location: true,
              commodity: { select: { name: true } },
            },
          },
        },
      },
      reviews: true,
    },
  });

  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }

  // Only buyer, farmer, or admin can view
  if (
    order.buyerId !== req.user!.id &&
    order.farmerId !== req.user!.id &&
    req.user!.role !== 'ADMIN'
  ) {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  res.json({ order });
});

// POST /api/orders - create new order (buyer only)
router.post('/', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  if (req.user!.role !== 'BUYER' && req.user!.role !== 'ADMIN') {
    res.status(403).json({ error: 'Only buyers can create orders' });
    return;
  }

  const { items, notes } = req.body as {
    items: Array<{ productId: string; quantity: number; unit: string }>;
    notes?: string;
  };

  if (!items || items.length === 0) {
    res.status(400).json({ error: 'Order must have at least one item' });
    return;
  }

  // Fetch all products
  const products = await prisma.product.findMany({
    where: { id: { in: items.map((i) => i.productId) }, isActive: true },
  });

  if (products.length !== items.length) {
    res.status(400).json({ error: 'One or more products not found or inactive' });
    return;
  }

  // Check all products belong to same farmer
  const farmerIds = [...new Set(products.map((p) => p.farmerId))];
  if (farmerIds.length > 1) {
    res.status(400).json({ error: 'All items must be from the same farmer' });
    return;
  }

  const farmerId = farmerIds[0];
  let totalAmount = 0;

  const orderItems = items.map((item) => {
    const product = products.find((p) => p.id === item.productId)!;
    const lineTotal = product.price * item.quantity;
    totalAmount += lineTotal;
    return {
      productId: item.productId,
      quantity: item.quantity,
      unit: item.unit || product.unit,
      price: product.price,
    };
  });

  const order = await prisma.order.create({
    data: {
      buyerId: req.user!.id,
      farmerId,
      totalAmount,
      notes,
      items: { create: orderItems },
    },
    include: {
      items: true,
      buyer: { select: { id: true, name: true } },
      farmer: { select: { id: true, name: true } },
    },
  });

  // Notify farmer
  await prisma.notification.create({
    data: {
      userId: farmerId,
      type: 'ORDER_UPDATE',
      title: 'New Order Received',
      message: `You have a new order from ${order.buyer.name} for ₹${totalAmount.toLocaleString('en-IN')}.`,
      data: JSON.stringify({ orderId: order.id }),
    },
  });

  res.status(201).json({ order });
});

// PATCH /api/orders/:id/status
router.patch('/:id/status', authenticate, async (req: AuthRequest, res: Response): Promise<void> => {
  const { status } = req.body as { status: string };

  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }

  const validTransitions: Record<string, string[]> = {
    FARMER: ['ACCEPTED', 'PROCESSING', 'READY', 'CANCELLED'],
    BUYER: ['CANCELLED'],
    ADMIN: ['PENDING', 'ACCEPTED', 'PROCESSING', 'READY', 'COMPLETED', 'CANCELLED'],
  };

  const allowed = validTransitions[req.user!.role] || [];
  if (!allowed.includes(status)) {
    res.status(403).json({ error: `Cannot set status to ${status} with your role` });
    return;
  }

  if (order.farmerId !== req.user!.id && order.buyerId !== req.user!.id && req.user!.role !== 'ADMIN') {
    res.status(403).json({ error: 'Not authorized' });
    return;
  }

  const updated = await prisma.order.update({
    where: { id: req.params.id },
    data: { status: status as 'PENDING' | 'ACCEPTED' | 'PROCESSING' | 'READY' | 'COMPLETED' | 'CANCELLED' },
  });

  // Notify the other party
  const notifyUserId = req.user!.id === order.farmerId ? order.buyerId : order.farmerId;
  await prisma.notification.create({
    data: {
      userId: notifyUserId,
      type: 'ORDER_UPDATE',
      title: 'Order Status Updated',
      message: `Your order #${order.id.slice(-8)} has been updated to: ${status}.`,
      data: JSON.stringify({ orderId: order.id }),
    },
  });

  res.json({ order: updated });
});

export default router;
