import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cron from 'node-cron';

import authRouter from './routes/auth';
import marketsRouter from './routes/markets';
import commoditiesRouter from './routes/commodities';
import pricesRouter from './routes/prices';
import marketplaceRouter from './routes/marketplace';
import ordersRouter from './routes/orders';
import alertsRouter from './routes/alerts';
import adminRouter from './routes/admin';
import dashboardRouter from './routes/dashboard';

import { syncMandiData } from './services/syncService';
import { checkAndTriggerAlerts } from './services/priceAlertService';
import { dataGovProvider } from './services/dataGovProvider';
import { prisma } from './lib/prisma';

const app = express();
const PORT = process.env.PORT || 3000;
const SYNC_INTERVAL_HOURS = parseInt(process.env.SYNC_INTERVAL_HOURS || '6');

// Middleware
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    apiConfigured: dataGovProvider.isConfigured(),
  });
});

// Routes
app.use('/api/auth', authRouter);
app.use('/api/markets', marketsRouter);
app.use('/api/commodities', commoditiesRouter);
app.use('/api/prices', pricesRouter);
app.use('/api/marketplace', marketplaceRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/admin', adminRouter);
app.use('/api/dashboard', dashboardRouter);

// 404
app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[Error]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// Scheduled sync (only if API key is configured)
if (dataGovProvider.isConfigured()) {
  const cronExpression = `0 */${SYNC_INTERVAL_HOURS} * * *`;
  cron.schedule(cronExpression, () => {
    console.log('[Cron] Starting scheduled mandi data sync...');
    syncMandiData().catch((err) => console.error('[Cron] Sync failed:', err));
  });

  // Check price alerts every hour
  cron.schedule('0 * * * *', () => {
    checkAndTriggerAlerts().catch((err) => console.error('[Cron] Alert check failed:', err));
  });

  console.log(`[Cron] Sync scheduled every ${SYNC_INTERVAL_HOURS} hours`);
} else {
  console.log('[Config] DATA_GOV_API_KEY not set — live sync disabled. Using cached/demo data.');
}

async function main() {
  try {
    await prisma.$connect();
    console.log('[DB] Connected to SQLite database');

    app.listen(PORT, () => {
      console.log(`[Server] KisanConnect backend running on http://localhost:${PORT}`);
      console.log(`[Server] API docs: http://localhost:${PORT}/health`);
      console.log(`[Server] API key configured: ${dataGovProvider.isConfigured()}`);
    });
  } catch (err) {
    console.error('[Fatal] Failed to start:', err);
    process.exit(1);
  }
}

main();
