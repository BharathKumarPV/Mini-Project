import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Package, ShoppingCart, User } from 'lucide-react';
import { marketplaceApi } from '../api/marketplace';
import { ordersApi } from '../api/orders';
import { useAuth } from '../hooks/useAuth';
import PriceTransparency from '../components/Marketplace/PriceTransparency';
import LoadingSkeleton from '../components/UI/LoadingSkeleton';
import type { Product, MarketPrice } from '../types';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [latestMarketPrice, setLatestMarketPrice] = useState<MarketPrice | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [orderLoading, setOrderLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderError, setOrderError] = useState('');
  const [qty, setQty] = useState(1);

  useEffect(() => {
    if (!id) return;
    setIsLoading(true);
    marketplaceApi.getProduct(id)
      .then(({ data }) => {
        setProduct(data.product);
        setLatestMarketPrice(data.latestMarketPrice);
      })
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, [id]);

  const handleOrder = async () => {
    if (!product) return;
    setOrderLoading(true);
    setOrderError('');
    try {
      await ordersApi.create({
        items: [{ productId: product.id, quantity: qty, unit: product.unit }],
      });
      setOrderSuccess(true);
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error ?? 'Failed to place order.';
      setOrderError(msg);
    } finally {
      setOrderLoading(false);
    }
  };

  if (isLoading) return <div className="page-container"><LoadingSkeleton type="text" rows={8} /></div>;
  if (!product) return <div className="page-container"><p className="text-gray-500">Product not found.</p></div>;

  const isOwnProduct = user?.id === product.farmerId;
  const canOrder = isAuthenticated && user?.role === 'BUYER' && !isOwnProduct;

  return (
    <div className="page-container max-w-4xl">
      <Link to="/marketplace" className="btn-ghost text-sm mb-6 inline-flex">
        <ArrowLeft className="w-4 h-4" /> Back to Marketplace
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left */}
        <div>
          {/* Image placeholder */}
          <div className="w-full h-56 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center mb-4">
            <Package className="w-16 h-16 text-green-400" />
          </div>

          <div className="card p-4">
            <div className="flex items-center gap-2 mb-2">
              <User className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-600">
                <span className="font-medium">{product.farmer?.name?.replace(' [DEMO]', '')}</span>
                {product.farmer?.farmerProfile && (
                  <span className="text-gray-400"> · {product.farmer.farmerProfile.district}, {product.farmer.farmerProfile.state}</span>
                )}
              </span>
            </div>
            <div className="flex items-center gap-1 text-sm text-gray-600">
              <MapPin className="w-4 h-4 text-gray-400" />
              {product.location}
            </div>
          </div>
        </div>

        {/* Right */}
        <div className="space-y-4">
          <div>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {product.isDemo && <span className="badge badge-demo">DEMO</span>}
              <span className="badge badge-gray">{product.commodity?.category}</span>
              <span className="badge badge-green">{product.commodity?.name}</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900 mb-1">{product.title}</h1>
            {product.description && <p className="text-sm text-gray-600">{product.description}</p>}
          </div>

          <div className="card p-4">
            <div className="flex items-baseline gap-1 mb-3">
              <span className="text-3xl font-bold text-green-700">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              <span className="text-gray-500">/ {product.unit}</span>
            </div>
            <p className="text-sm text-gray-600">
              <span className="font-medium">{product.quantity.toLocaleString('en-IN')} {product.unit}</span> available
            </p>
          </div>

          {/* Price Transparency */}
          <PriceTransparency
            productPrice={product.price}
            productUnit={product.unit}
            latestMarketPrice={latestMarketPrice}
          />

          {/* Order section */}
          {canOrder && !orderSuccess && (
            <div className="card p-4">
              <h3 className="font-semibold mb-3 text-sm">Place Order</h3>
              <div className="flex items-center gap-3 mb-3">
                <label className="text-sm text-gray-600">Quantity ({product.unit})</label>
                <input
                  type="number"
                  min={1}
                  max={product.quantity}
                  value={qty}
                  onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
                  className="input w-24"
                />
              </div>
              <p className="text-sm font-medium text-gray-700 mb-3">
                Total: ₹{(product.price * qty).toLocaleString('en-IN')}
              </p>
              {orderError && <p className="text-red-500 text-xs mb-3">{orderError}</p>}
              <button onClick={handleOrder} disabled={orderLoading} className="btn-primary w-full">
                <ShoppingCart className="w-4 h-4" />
                {orderLoading ? 'Placing Order...' : 'Place Order'}
              </button>
              <p className="text-xs text-gray-400 mt-2 text-center">Order goes to farmer for review</p>
            </div>
          )}

          {orderSuccess && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-sm text-green-700">
              ✓ Order placed successfully. Check your dashboard for status updates.
            </div>
          )}

          {!isAuthenticated && (
            <Link to="/login" className="btn-primary w-full justify-center">
              Sign in to place an order
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
