import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, TrendingUp, Heart, Bell } from 'lucide-react';
import apiClient from '../api/client';
import { useAuth } from '../hooks/useAuth';
import LoadingSkeleton from '../components/UI/LoadingSkeleton';
import type { Order, Notification } from '../types';

interface DashboardData {
  stats: { totalOrders: number; totalSpent: number; pendingOrders: number; savedProducts: number };
  recentOrders: Order[];
  notifications: Notification[];
  favorites: Array<{ id: string; product: { id: string; title: string; price: number; unit: string; farmer: { name: string } } }>;
}

function getOrderBadge(status: string): string {
  switch (status) {
    case 'PENDING': return 'badge-amber';
    case 'ACCEPTED': return 'badge-blue';
    case 'PROCESSING': return 'badge-blue';
    case 'READY': return 'badge-green';
    case 'COMPLETED': return 'badge-green';
    case 'CANCELLED': return 'badge-red';
    default: return 'badge-gray';
  }
}

export default function BuyerDashboardPage() {
  const { user } = useAuth();
  const [dashData, setDashData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    apiClient.get('/dashboard/buyer').then(({ data }) => setDashData(data)).catch(console.error).finally(() => setIsLoading(false));
  }, []);

  if (isLoading) return <div className="page-container"><LoadingSkeleton type="card" rows={4} /></div>;

  const stats = dashData?.stats;

  return (
    <div className="page-container">
      <div className="mb-6">
        <h1 className="section-heading">Buyer Dashboard</h1>
        <p className="text-sm text-gray-500">Welcome, {user?.name.replace(' [DEMO]', '')} 🛒</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Orders', value: stats?.totalOrders ?? 0, icon: ShoppingCart, color: 'text-green-700' },
          { label: 'Pending Orders', value: stats?.pendingOrders ?? 0, icon: ShoppingCart, color: 'text-amber-600' },
          { label: 'Total Spent (₹)', value: `₹${(stats?.totalSpent ?? 0).toLocaleString('en-IN')}`, icon: TrendingUp, color: 'text-blue-600' },
          { label: 'Saved Products', value: stats?.savedProducts ?? 0, icon: Heart, color: 'text-pink-500' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-4">
            <div className="flex items-center gap-2 mb-2">
              <Icon className={`w-4 h-4 ${color}`} />
              <span className="text-xs text-gray-500">{label}</span>
            </div>
            <p className={`text-xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">My Orders</h2>
            <Link to="/marketplace" className="text-xs text-green-700 hover:underline">Browse more</Link>
          </div>
          {(dashData?.recentOrders ?? []).length === 0 ? (
            <div>
              <p className="text-sm text-gray-500 mb-3">No orders yet.</p>
              <Link to="/marketplace" className="btn-primary text-sm">Browse Marketplace</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {dashData?.recentOrders.map((o) => (
                <div key={o.id} className="py-2 border-b border-gray-100 last:border-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-gray-900">#{o.id.slice(-8)}</p>
                    <span className={`badge text-xs ${getOrderBadge(o.status)}`}>{o.status}</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    from {o.farmer?.name?.replace(' [DEMO]', '')} · ₹{o.totalAmount.toLocaleString('en-IN')}
                  </p>
                  <p className="text-xs text-gray-400">{new Date(o.createdAt).toLocaleDateString('en-IN')}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Saved Products */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Saved Products</h2>
          </div>
          {(dashData?.favorites ?? []).length === 0 ? (
            <p className="text-sm text-gray-500">No saved products yet. Browse the marketplace and save items.</p>
          ) : (
            <div className="space-y-3">
              {dashData?.favorites.map((f) => (
                <div key={f.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                  <div>
                    <p className="text-sm font-medium">{f.product.title}</p>
                    <p className="text-xs text-gray-500">
                      ₹{f.product.price.toLocaleString('en-IN')}/{f.product.unit} · {f.product.farmer.name.replace(' [DEMO]', '')}
                    </p>
                  </div>
                  <Link to={`/marketplace/${f.product.id}`} className="text-xs text-green-700 hover:underline">View</Link>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notifications */}
        {(dashData?.notifications ?? []).length > 0 && (
          <div className="card p-5 lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="w-4 h-4 text-green-700" />
              <h2 className="font-semibold">Notifications</h2>
            </div>
            <div className="space-y-3">
              {dashData?.notifications.map((n) => (
                <div key={n.id} className="flex gap-3 py-2 border-b border-gray-100 last:border-0">
                  <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">{n.title}</p>
                    <p className="text-xs text-gray-500">{n.message}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Price intelligence */}
      <div className="mt-6 card p-5 bg-amber-50 border-amber-200">
        <h3 className="font-semibold text-amber-800 mb-1">Market Intelligence</h3>
        <p className="text-sm text-amber-700 mb-3">Check mandi prices before placing large orders.</p>
        <div className="flex gap-3">
          <Link to="/mandi-prices" className="btn-accent text-sm">Check Mandi Prices</Link>
          <Link to="/mandi-compare" className="btn-ghost text-sm">Compare Markets</Link>
        </div>
      </div>
    </div>
  );
}
