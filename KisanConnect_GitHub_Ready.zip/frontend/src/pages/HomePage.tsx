import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, ShoppingBag, MapPin, TrendingUp, ArrowRight, Sprout, AlertTriangle } from 'lucide-react';
import apiClient from '../api/client';
import PriceCard from '../components/Mandi/PriceCard';
import LoadingSkeleton from '../components/UI/LoadingSkeleton';
import type { MarketPrice } from '../types';

interface Stats {
  markets: number;
  commodities: number;
  products: number;
  states: number;
}

const FEATURES = [
  {
    icon: BarChart3,
    title: 'Live Mandi Prices',
    description: 'Access daily wholesale prices from APMC markets across India, sourced from the Government of India data portal.',
    link: '/mandi-prices',
    color: 'bg-green-50',
    iconColor: 'text-green-700',
  },
  {
    icon: TrendingUp,
    title: 'Price Trends & History',
    description: 'Analyse 90-day price history, spot seasonal patterns, and compare prices across multiple markets.',
    link: '/price-trends',
    color: 'bg-blue-50',
    iconColor: 'text-blue-700',
  },
  {
    icon: ShoppingBag,
    title: 'Direct Marketplace',
    description: 'Farmers list produce directly; buyers discover and connect — cutting out unnecessary middlemen.',
    link: '/marketplace',
    color: 'bg-amber-50',
    iconColor: 'text-amber-700',
  },
  {
    icon: MapPin,
    title: 'Market Map',
    description: 'Visualise APMC markets across India on an interactive map to find the nearest trading location.',
    link: '/mandi-map',
    color: 'bg-purple-50',
    iconColor: 'text-purple-700',
  },
];

export default function HomePage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [latestPrices, setLatestPrices] = useState<MarketPrice[]>([]);
  const [pricesLoading, setPricesLoading] = useState(true);

  useEffect(() => {
    apiClient.get('/dashboard/stats').then(({ data }) => setStats(data)).catch(console.error);
    apiClient
      .get('/prices/latest', { params: { limit: 6 } })
      .then(({ data }) => setLatestPrices(data.data))
      .catch(console.error)
      .finally(() => setPricesLoading(false));
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-b from-green-900 to-green-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <Sprout className="w-5 h-5 text-green-300" />
              <span className="text-green-300 text-sm font-medium">Powered by data.gov.in AGMARKNET</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold leading-tight mb-4">
              India's Agriculture Market,{' '}
              <span className="text-amber-400">Connected.</span>
            </h1>
            <p className="text-lg text-green-200 mb-8 leading-relaxed">
              Track mandi prices, compare markets, discover agricultural products and connect
              farmers with buyers directly. Real data from Government of India open portals.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/mandi-prices" className="btn-accent text-base px-6 py-3">
                Check Mandi Prices <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/marketplace" className="bg-white/10 hover:bg-white/20 text-white border border-white/30 inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors text-base">
                Explore Marketplace
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      {stats && (
        <section className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              {[
                { label: 'APMC Markets', value: stats.markets.toLocaleString('en-IN') },
                { label: 'Commodities Tracked', value: stats.commodities.toLocaleString('en-IN') },
                { label: 'States Covered', value: stats.states.toLocaleString('en-IN') },
                { label: 'Marketplace Listings', value: stats.products.toLocaleString('en-IN') },
              ].map(({ label, value }) => (
                <div key={label} className="text-center">
                  <p className="text-2xl font-bold text-green-700">{value}</p>
                  <p className="text-sm text-gray-500">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Latest Prices */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="section-heading">Today's Mandi Prices</h2>
              <p className="section-subheading">Latest wholesale prices from APMC markets</p>
            </div>
            <Link to="/mandi-prices" className="btn-secondary text-sm hidden sm:inline-flex">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {pricesLoading ? (
            <LoadingSkeleton type="card" rows={6} />
          ) : latestPrices.length === 0 ? (
            <div className="card p-8 text-center">
              <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-700 mb-1">No price data yet</h3>
              <p className="text-sm text-gray-500 mb-4">
                Configure your DATA_GOV_API_KEY and run a sync to populate live mandi data, or run the seed script for demo data.
              </p>
              <Link to="/mandi-prices" className="btn-secondary text-sm">Go to Mandi Prices</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {latestPrices.map((p) => (
                <PriceCard key={p.id} price={p} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Everything You Need</h2>
            <p className="text-gray-500">From farm gate to wholesale market — one platform</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map(({ icon: Icon, title, description, link, color, iconColor }) => (
              <Link key={link} to={link} className="card p-6 hover:shadow-md transition-shadow group">
                <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 ${iconColor}`} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-green-700 transition-colors">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">How It Works</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Check Prices', desc: 'Browse live APMC mandi prices from Government of India data. Filter by commodity, state, or market.' },
              { step: '02', title: 'Analyse & Compare', desc: 'View historical price trends, compare prices across multiple mandis, and identify the best market for your produce.' },
              { step: '03', title: 'Connect & Transact', desc: 'Farmers list produce on the marketplace; buyers discover and place orders — with full price transparency.' },
            ].map(({ step, title, desc }) => (
              <div key={step} className="text-center">
                <div className="w-12 h-12 bg-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-sm">{step}</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Data disclaimer */}
      <section className="py-6 bg-amber-50 border-t border-amber-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-amber-800">
          <strong>Data disclaimer:</strong> Mandi price data is sourced from{' '}
          <a href="https://data.gov.in" className="underline" target="_blank" rel="noopener noreferrer">
            data.gov.in
          </a>{' '}
          (AGMARKNET/NHM). Prices are indicative wholesale rates as reported by APMC markets. Verify
          prices locally before transacting. Marketplace listings marked [DEMO] are for demonstration only.
        </div>
      </section>
    </div>
  );
}
